Create a 'dummy' Renesas RA C Project Using RA Library.
Copy and Paste the generated 'script' and 'src' folder into this folder.

These are linked to in other projects.
